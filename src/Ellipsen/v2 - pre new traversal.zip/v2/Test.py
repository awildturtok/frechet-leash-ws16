########################################################################################################################
#                                                                                                                      #
#                                    Software Projekt: Frechet Distanz                                                 #
#                                    Teilgebiet: Ellipsen-Alg. einer Zelle                                             #
#                                    Erstellt: WS 16/17 FU Berlin                                                      #
#                                                                                                                      #
#                                    Team: Josephine Mertens, Jana Kirschner,                                          #
#                                    Alexander Korzech, Fabian Kovacs, Alexander                                       #
#                                    Timme, Kilian Kraatz & Anton Begehr                                               #
#                                                                                                                      #
########################################################################################################################

# -*- coding: utf-8 -*-

from Graphics import *

import numpy as np


n_l = 9  # number of height lines
n_p = 50  # points per ellipsis

# path_a:
a_xs = [10, -10, 5]
a_ys = [0, 0, 5]

# path_b:
b_xs = [-8, 12, 12, 0, -10]
b_ys = [-2, -2, 2, 10, 5]

'''# path_a:
a_xs = np.random.random_sample(7)
a_ys = np.random.random_sample(7)

# path_b:
b_xs = np.random.random_sample(7)
b_ys = np.random.random_sample(7)'''


path_b = xy_to_vectors(a_xs, a_ys)
path_a = xy_to_vectors(b_xs, b_ys)

input1 = CellMatrix(path_a, path_b, traverse=1)
print(input1)

sample1 = input1.sample_l(n_l, n_p)

sample_to_matplotlib(sample1, plot_3d=False, plot_traversals=True, plot_critical_traversals=True)
