#include <QApplication>
#include <QQmlApplicationEngine>
#include <QtQuick>
#include <QtCharts/QChartView>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    QObject *window = engine.rootObjects().at(0);
    QObject *chart = window->children().at(0);

    return app.exec();
}

