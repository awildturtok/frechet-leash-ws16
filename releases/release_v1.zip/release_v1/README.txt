Start des Programms:

Zum Starten von frechet.exe im Verzeichnis ReleaseBuild muss Qt in der Version 5.8.0 auf dem System installiert sein. 
Dies ist die Vollversion der entwickelten Software.

Des Weiteren liegt ein static build bereit. Die Datei frechet.exe im StaticBuild Verzeichnis kann ohne vorherige 
Installation von QT ausgef�hrt werden. Diese Version unterst�tzt jedoch nur die Koordinateneingabe 
�ber die Texteingabe.